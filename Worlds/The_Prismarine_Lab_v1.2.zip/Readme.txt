= The Prismarine Lab =
- An Adventure / Puzzle Map for two players -

You go down into the deep sea with a submarine
to find the hidden research station under water.
Once you enter the station, you want to find all the treasures.
But there are many traps and puzzles in your way.
Your knowledge and skills are demanded!

Rules:
- You're playing in adventure mode, so the breaking and placing are restricted.
- Prismarine crystals are the hidden treasures.
- If the wall is one color, just one player is allowed to go there.
- Crafting is not allowed in your inventory. Only on a crafting table.
- Play in easy (not peaceful), so you can die sometimes.
- If you went wrong, it is sometimes necessary to die in standing water.

Information:
- Compatible with Minecraft 1.8
- Requires command block support (when playing on servers)
- Disable clouds
- Please enable sound
- Set the GUI size to normal
- There are two players needed
- There are 30 rooms which are passed one by one
- It is recommended the texture pack: "R3D.Craft Default Realism" or the default pack
- Map-Version: 1.2 (2016-10-30)
- Created by warco311, MaxLoewe, christina_12

Terms of use:
- Do not upload / publish anywhere.
- However you are welcome to link the download page.
- When publishing screenshots / videos please link the post.
- The map was a lot of work, please respect the terms of use.

Enjoy & Thanks for playing :)
